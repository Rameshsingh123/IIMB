// @ts-nocheck
const fs = require('fs');
const path = require('path');

// Set the directory path where the Groovy files are located
const groovyDirectoryPath = '/home/sumotech/Documents/katalon to selenium conversion scripts/groovy';

const pytestDirectoryPath = '/home/sumotech/Documents/katalon to selenium conversion scripts/pytest';

// Define the regular expression patterns to match the keywords in the Groovy files
const featurePattern = /@Feature\("(.+)"\)/;
const scenarioPattern = /@Scenario\("(.+)"\)/;
const givenPattern = /Given\("(.+)"\)/g;
const whenPattern = /When\("(.+)"\)/g;
const thenPattern = /Then\("(.+)"\)/g;

// Loop through all files in the directory
fs.readdir(groovyDirectoryPath, (err, files) => {
    if (err) {
        console.log('Error reading directory:', err);
        return;
    }

    files.forEach(file => {
        const filePath = path.join(groovyDirectoryPath, file);

        // Read the contents of the Groovy file
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                console.log('Error reading file:', err);
                return;
            }

            // Extract the feature, scenario, and step information from the Groovy file
            const featureMatch = data.match(featurePattern);
            const scenarioMatch = data.match(scenarioPattern);
            const givenMatches = data.matchAll(givenPattern);
            const whenMatches = data.matchAll(whenPattern);
            const thenMatches = data.matchAll(thenPattern);

            // Construct the Pytest file content using the extracted information
            const pytestContent = `
            import pytest
            from selenium import webdriver

            @pytest.fixture(scope="module")
            def driver():
                driver = webdriver.Chrome()
                yield driver
                driver.quit()

            @pytest.mark.${featureMatch[1].toLowerCase().replace(/\s/g, '_')}
            
            def test_${scenarioMatch[1].toLowerCase().replace(/\s/g, '_')}(driver):
                ${[...givenMatches].map(match => `    ${match[1]}\n`).join('')}
                ${[...whenMatches].map(match => `    ${match[1]}\n`).join('')}
                ${[...thenMatches].map(match => `    ${match[1]}\n`).join('')}`;

            // Write the Pytest file to disk
            const pytestFilePath = path.join(pytestDirectoryPath, `${path.parse(file).name}.py`);
            fs.writeFile(pytestFilePath, pytestContent, err => {
                if (err) {
                    console.log('Error writing file:', err);
                    return;
                }
                console.log('Pytest file created:', pytestFilePath);
            });
        });
    });
});