import os
import re
import asyncio

# Set up Katalon Cucumber Groovy and feature file paths and Pytest output directory
groovy_dir = '/home/ramesh/Documents/katalon to selenium conversion scripts/Login.groovy'
pytest_dir = '/home/ramesh/Documents/katalon to selenium conversion scripts/test_Login.py'


async def read_file(file_path):
    with open(file_path, "r") as f:
        return f.read()


async def process_file(file_path):
    file_content = await read_file(file_path)
    return file_content


async def main():
    # Loop through all files in groovy directory
    for filename in os.listdir(groovy_dir):
        pytest_file = """
        from selenium import webdriver
        import pytest

        # Set up Selenium webdriver
        driver = webdriver.Chrome()

        # Set up Pytest
        # @pytest.fixture(scope='session')
        def browser():
            return driver

        # # Close the Selenium webdriver
        # driver.quit()

        """

        # Process groovy file
        groovy_file_path = os.path.join(groovy_dir, filename)
        if os.path.isfile(groovy_file_path):
            # Read contents
            with open(groovy_file_path, "r") as f:
                groovy_file = await process_file(groovy_file_path)

        # Extract Class
        class_str = re.search(r"class .*?{", groovy_file)
        if class_str:
            class_str = class_str.group()
            class_str = class_str.replace("class ", "")
            class_str = class_str.replace(" {", "")

        # Extract the scenarios from the feature file
        scenarios = re.split(r'@Given.*?', groovy_file, 0, re.DOTALL)

        # Remove 0th item as it possibly contains import prior to a test scenario
        del scenarios[0]

        # Iterate through the scenarios
        for i, scenario in enumerate(scenarios):

            if ((i != 0) and (i < len(scenarios) - 1)):
                pytest_file += "\n\n"

            scenario = "@Given" + scenario

            # Extract each sub Fn i.e., Given, When, And, Then
            step_fn_group = re.findall(r'@.*?}', scenario, re.DOTALL)

            for j, step_fn in enumerate(step_fn_group):

                fn_description = re.search(r"\".*?\"", step_fn)
                if fn_description:
                    fn_description = fn_description.group()
                    fn_description = fn_description.replace("\"", "")

                    fn_description = "# " + fn_description

                pytest_file += fn_description

                fn = re.search(r'def.*?}', step_fn, re.DOTALL)
                if fn:
                    fn = fn.group()

                    fn = "\n" + re.sub(r"\(\).*?{", "():", fn, flags=re.DOTALL)

                    fn = fn.replace("}", "")

                    fn = fn.replace("WebUI.openBrowser", "browser.get")
                    fn = fn.replace("WebUI.maximizeWindow", "browser.get")

                pytest_file += fn

        # driver close code goes here

        # Save the Pytest test case code to a file
        with open(os.path.join(pytest_dir, f"{class_str}.py"), 'w') as f:
            f.write(pytest_file)


# Run the main function asynchronously
asyncio.run(main())
