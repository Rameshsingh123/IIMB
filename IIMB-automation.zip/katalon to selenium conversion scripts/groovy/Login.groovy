import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testdata.reader.CSVSeparator
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When

import com.kms.katalon.core.testdata.CSVData
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

class Login {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */

	CSVData csvData = new CSVData('/home/ramesh/Documents/LoginData.csv', true, CSVSeparator.COMMA);


	// Designer enters ce-game url in a browser

	@Given("Designer opens browser")
	def I_want_to_write_a_step_with_name() {
		println "inside step"
		WebUI.openBrowser('')
		WebUI.maximizeWindow()
	}

	@When("Designer enters ce-game url in a browser")
	def I_check_for_the_value_in_step() {
		WebUI.navigateToUrl("https://cegame.iimb.ac.in/")
		WebUI.delay(1)

	}

	@Then("Designer should navigate to login page")
	def I_verify_the_status_in_step() {
		Boolean val =WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Log_In_Button'), 1)
		println "Login "+val
	}

	// Verify UI elements on Login screen
	@Given("Designer is on cegame login screen")
	def Designer_is_on_cegame_login_screen()
	{

	}
	@When("verify UI elements of login screen iimb logo, Welcome corporate enterpreneurship simulation title")
	def verify_UI_elements_of_login_screen_iimb_logo_Welcome_corporate_enterpreneurship_simulation_title()
	{
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/IIMB Logo'), 1)

		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Welcome to Corporate Entrepreneurship Simulation'), 1)


	}
	@And("Backgroung image, url, email input, password input, login button, forgot password")
	def Backgroungimage_url_email_input_password_input_login_button_forgot_password()
	{
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Password'), 1)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Email'), 1)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Log_In_Button'), 1)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Forgot_password'),1)
	}

	// Designer clicks on login button with empty email id and password
	@When("Designer clicks on login button with empty email and password")
	def Designer_clicks_on_login_button_with_empty_email_and_password()
	{
		WebUI.delay(1)
		WebUI.click(findTestObject('Object Repository/Login_Page/Log_In_Button'))
	}
	@Then("Designer should get error message Emailid is required and Password is required")
	def Designer_should_get_error_message_Emailid_is_required_Password_is_required(){

		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/EmailId_is_required'), 1)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Password_is_required'), 1)

	}

	// Designer clicks on forgot password with vaild email
	@And("Designer enters valid email id")
	def Designer_enters_valid_email_id(){
		def Email = csvData.getValue("Email", 1)
		println 'Email = '+Email
		WebUI.setText(findTestObject('Object Repository/Login_Page/Email'), Email)
	}

	@When("Designer clicks on forgot password?")
	def Designer_clicks_on_forgot_password(){

		WebUI.click(findTestObject('Object Repository/Login_Page/Forgot_password'))
	}

	@Then("Designer should get toast message Email with new password will be sent if you are a registered user")
	def Designer_should_get_toast_message_Email_with_new_password_will_be_sent_if_you_are_a_registered_user(){

		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/Email with new password will be sent if you are a registered user'), 1)
		WebUI.clearText(findTestObject('Object Repository/Login_Page/Email'))

	}

	// Designer clicks on login button with Valid email id and password

	@When("Designer clicks on login button with valid email id and password")
	def Designer_clicks_on_login_button_with_valid_email_id_and_password()
	{
		WebUI.waitForElementVisible(findTestObject('Object Repository/Login_Page/Email'),5)
		def email = csvData.getValue("Email", 2)
		def password = csvData.getValue("Password", 2)
		WebUI.setText(findTestObject('Object Repository/Login_Page/Email'), email)
		WebUI.setText(findTestObject('Object Repository/Login_Page/Password'), password)
		WebUI.click(findTestObject('Object Repository/Login_Page/Log_In_Button'))

	}

	@Then("Designer should navigate to cegame dashboard screen")
	def Designer_should_navigate_to_cegame_dashboard_screen(){
		WebUI.delay(2)
		WebUI.verifyElementPresent(findTestObject('Object Repository/Login_Page/ Create Game'), 10)
	}




}