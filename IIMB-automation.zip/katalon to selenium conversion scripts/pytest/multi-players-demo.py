from threading import Thread

import pytest
import time

import self
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from pytest_html_reporter import attach
import csv


@pytest.mark.usefixtures("browser")
class TestLogin:
    @pytest.fixture(autouse=True)
    def setup(self, browser):
        self.browser = browser

    # # Designer opens browser
    # def test_i_want_to_write_a_step_with_name(self):
    #     self.browser.get("https://google.com")
    #     self.browser.maximize_window()
    #     time.sleep(1)
    #    # self.browser.close()

    # def test_open_multiple_urls(self):
    #     urls = ['https://www.example1.com', 'https://www.example2.com', 'https://www.example3.com']  # List of URLs to open
    #     for url in urls:
    #         self.browser.get(url)

    def test_open_multi_tabs(self):
    # Open the first tab
        self.browser.get("https://www.example.com")
    # Open the second new tab
        self.browser.execute_script("window.open('https://www.google.com', '_blank')")
    # Switch to the second window
        self.browser.switch_to.window(self.browser.window_handles[1])
    # Open the third window in a new tab
        self.browser.execute_script("window.open('https://www.facebook.com', '_blank')")
    # Switch to the third window
        self.browser.switch_to.window(self.browser.window_handles[2])
    # Assert that the current URL is facebook.com
        assert self.browser.current_url == "https://www.facebook.com/"

# Multi- Windows

    def test_open_multi_windows(self):

        self.browser.get("https://www.amazon.com/")
        self.browser.switch_to.new_window('window')
        self.browser.get("https://www.myntra.com/")
        self.browser.switch_to.new_window('window')

        self.browser.get("https://www.google.com/")
        self.browser.switch_to.new_window('window')
        self.browser.get("https://www.flipkart.com/")
        self.browser.switch_to.new_window('window')

        self.browser.get("https://www.wiki.com/")
        self.browser.switch_to.new_window('window')
        self.browser.get("https://www.apple.com/")
        self.browser.switch_to.new_window('window')

        self.browser.get("https://www.samsung.com/")
        self.browser.switch_to.new_window('window')
        self.browser.get("https://www.dell.com/")
        self.browser.switch_to.new_window('window')



