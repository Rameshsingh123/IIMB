import csv

import constants
import pytest
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import pyautogui
import tkinter
import mouseinfo


@pytest.mark.usefixtures("browser")
class TestCompanyBriefandLogo:

    @pytest.fixture(autouse=True)
    def setup(self, browser):
        self.browser = browser

    async def read_csv_file(file_path):
        with open(file_path, "r") as f:
            return list(csv.reader(f))

    async def process_csv_file(file_path):
        file_content = await read_file(file_path)
        return file_content

    # Designer is on Dash board
    async def test_designer_is_on_dash_board(self):
        self.browser.get("https://cegame.iimb.ac.in/")
        time.sleep(3)
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_username).send_keys(
            'bharat.hegde@tibilsolutions.com')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_password).send_keys(
            'a84eb8f3')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_button_log_in).click()
        time.sleep(5)

    # Designer Clicks on Comapnies tab
    async def test_designer_cliks_on_companies_tab(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_companiestab).click()
        time.sleep(3)

    # Designer Click On Add Company
    async def test_designer_cliks_on_add_company(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_clkadd_company).click()
        time.sleep(2)

    # Designer Enters Company name
    async def test_designer_enters_valid_company_name(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_txtcompanyname).send_keys('Tibil Solution')
        time.sleep(2)

    # Designer Enter Brief
    async def test_designer_enter_brief(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_tetcompanybrief).send_keys('test')
        time.sleep(2)

    # # Designer Enter Logo
    # async def test_designer_enter_logo(self):
    #     element_locator = self.browser.find_element(By.XPATH, constants.brief_and_logo_details_label_upload_logo).click()



    # Designer Enter MNC Income
    async def test_designer_enter_valid_mnc_income(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_txtmnc_incom).send_keys('100')

    # Designer Enter Project Ask
    async def test_designer_enter_valid_project_ask(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_txtproject_ask).send_keys('50')

    # Designer Enter Payoff Matrix
    async def test_designer_enter_valid_payoff_matrix(self):
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_spin_off_spinoff1).send_keys('-1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_internalize_internalize1).send_keys(
            '1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_shut_down_shutdown1).send_keys('2')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_td_please_enter_valid_payoff_value).click()
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_incubate_incubate1).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_spin_off_spinoff2).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_internalize_internalize2).send_keys(
            '1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_shut_down_shutdown2).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_incubate_incubate2).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_spin_off_spinoff3).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_internalize_internalize3).send_keys(
            '1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_shut_down_shutdown3).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_incubate_incubate3).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_spin_off_spinoff4).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_internalize_internalize4).send_keys(
            '1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_shut_down_shutdown4).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_input_incubate_incubate4).send_keys('1')
        self.browser.find_element(By.XPATH, constants.brief_and_logo_details_button_add_subsidiaries).click()

    # # Designer Click on add subsidiery
    # async def test_designer_clik_on_add_subsidiery(self):
    #     self.browser.find_element(By.XPATH, constants.brief_and_logo_details_button_add_subsidiaries).click()
    #
    # # Designer should move to subsidiries Screen
    # async def test_designer_should_move_to_subsidiriesscreen(self):
    #     print('no statements here')

    # # Designer Clicks on Search
    # async def test_designer_clicks_on_search_button(self):
    #     self.browser.find_element(By.XPATH, constants.search_company_searchcompany).send_keys('go Group')
    #
    # # Designer Should Display company cards
    # async def test_designer_should_display_company_cards(self):
    #     wait = WebDriverWait(self.browser, 30)
    #     element = wait.until(EC.presence_of_element_located(By.XPATH, constants.search_company_div_go_group))
    #     assert element.is_displayed()
    #     wait = WebDriverWait(self.browser, 30)
    #     element = wait.until(EC.presence_of_element_located(By.XPATH, constants.search_company_searchcompany))
    #     assert element.is_displayed()
    #
    # # Designer Enter blank Logo
    # async def test_designer_enter_blank_logo(self):
    #     print('no statements here')

    # # Designer Should display Error message
    # async def test_designer_should_display_error_message(self):
    #     print("")
    #
    # # Designer Should display Error ProjectAsk should be less than MNC Income.
    # async def test_designer_should_display_error_projectask_should_be_less_than_mnc_income(self):
    #     print('no statements here')
