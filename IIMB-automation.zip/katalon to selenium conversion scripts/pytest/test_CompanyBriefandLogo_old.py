import pytest
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


@pytest.mark.usefixtures("browser")
class TestCompanyBriefandLogo:

    @pytest.fixture(autouse=True)
    def setup(self, browser):
        self.browser = browser

    # Designer is on Dash board
    def test_login(self):
        self.browser.get("https://cegame.iimb.ac.in/")
        time.sleep(3)
        self.browser.find_element(By.XPATH, "//input[@id='email']").send_keys("bharat.hegde@tibilsolutions.com")
        self.browser.find_element(By.XPATH, "//input[@id='password']").send_keys('e961519a')
        self.browser.find_element(By.XPATH, "//button[@id='loginButton']").click()
        time.sleep(5)

    # Designer Clicks on Comapnies tab
    def test_designer_cliks_on_companies_tab(self):
        self.browser.find_element(By.XPATH, "//a[normalize-space()='Companies']").click()
        time.sleep(3)

    # Designer Click On Add Company
    def test_designer_cliks_on_add_company(self):
        self.browser.find_element(By.XPATH, "//span[normalize-space()='Add Company']").click()
        time.sleep(2)

    # Designer Enters Company name
    def test_designer_enters_valid_company_name(self):
        self.browser.find_element(By.XPATH, "//input[@id='name']").send_keys("Appzui")
        time.sleep(3)

    # Designer Enter Brief
    def test_designer_enter_brief(self):
        self.browser.find_element(By.XPATH, "//textarea[@id='brief']").send_keys('test')
        time.sleep(3)

    # Designer Enter Logo
    def test_designer_enter_logo(self):
        element_locator = self.browser.find_element(By.XPATH, "//div[@id='uploadlogo']/label").click()
    #     # element = WebDriverWait(self.browser, 10).until(EC.presence_of_element_located(element_locator))
    #     element_locator.send_keys('/home/ramesh/Documents/test.png')
    #     time.sleep(100)

    # Designer Enter MNC Income
    def test_designer_enter_valid_mnc_income(self):
        self.browser.find_element(By.XPATH, "//input[@id='companyFunding']").send_keys('10')

    # Designer Enter Project Ask
    def test_designer_enter_valid_project_ask(self):
        self.browser.find_element(By.XPATH, "//input[@id='projectAsk']").send_keys('100')

    # Designer Enter Payoff Matrix
    def test_designer_enter_valid_payoff_matrix(self):
        self.browser.find_element(By.XPATH, "//input[@id='Spinoff1']").send_keys('-1')
        self.browser.find_element(By.XPATH, "//input[@id='Internalize1']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Shutdown1']").send_keys('2')
        self.browser.find_element(By.XPATH, "//form[@id='newCompanyBriefLogoForm']/div/div/div[6]/div/table/tbody/tr[4]/td[2]").click()
        self.browser.find_element(By.XPATH, "//input[@id='Incubate1']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Spinoff2']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Internalize2']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Shutdown2']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Incubate2']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Spinoff3']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Internalize3']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Shutdown3']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Incubate3']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Spinoff4']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Internalize4']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Shutdown4']").send_keys('1')
        self.browser.find_element(By.XPATH, "//input[@id='Incubate4']").send_keys('1')
        self.browser.find_element(By.XPATH, "//button[@type='submit']").click()

    # Designer Click on add subsidiery
    def test_designer_clik_on_add_subsidiery(self):
        self.browser.find_element(By.XPATH, "//button[@type='submit']").click()

    # Designer should move to subsidiries Screen
    def test_designer_should_move_to_subsidiriesscreen(self):
        print('no statements here')

    # Designer Clicks on Search
    def test_designer_clicks_on_search_button(self):
        self.browser.find_element_by_xpath("//input[@id='searchCompanyBar']").send_keys('go Group')

    # Designer Should Display company cards
    def test_designer_should_display_company_cards(self):
        wait = WebDriverWait(self.browser, 30)
        element = wait.until(
            EC.presence_of_element_located((By.XPATH, "//div[@id='CompanyWrapper']/div/div/div/a/div/div")))
        assert element.is_displayed()
        wait = WebDriverWait(self.browser, 30)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='searchCompanyBar']")))
        assert element.is_displayed()

    # Designer Enter blank Logo
    def test_designer_enter_blank_logo(self):
        print('no statements here')

    # Designer Should display Error message
    def test_designer_should_display_error_message(self):
        print("")

    # Designer Should display Error ProjectAsk should be less than MNC Income.
    def test_designer_should_display_error_projectask_should_be_less_than_mnc_income(self):
        print('no statements here')
