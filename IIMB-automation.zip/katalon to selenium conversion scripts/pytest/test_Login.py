import pytest
import time
import constants
import self
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from pytest_html_reporter import attach
import csv


@pytest.mark.usefixtures("browser")
class TestLogin:
    csv_data = []

    def test_read_csv(self):
        with open("/home/ramesh/Documents/LoginData.csv", 'r') as f:
            self.csv_data = list(csv.reader(f))
            print(self.csv_data)
            return self.csv_data

    @pytest.fixture(autouse=True)
    def setup(self, browser):
        self.browser = browser

    # Designer opens browser
    def test_i_want_to_write_a_step_with_name(self):
        self.browser.maximize_window()

    # Designer enters ce-game url in a browser
    def test_i_check_for_the_value_in_step(self):
        self.browser.get("https://cegame.iimb.ac.in/")
        time.sleep(1)

    # Designer should navigate to login page
    def test_i_verify_the_status_in_step(self):
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//button[@id='loginButton']")))
        assert element.is_displayed()

    # Designer is on cegame login screen
    def test_designer_is_on_cegame_login_screen(self):
        print('no statements here')

    # verify UI elements of login screen iimb logo, Welcome corporate enterpreneurship simulation title
    def test_verify_ui_elements_of_login_screen_iimb_logo_welcome_corporate_enterpreneurship_simulation_title(self):
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//form[@id='loginForm']/a/img")))
        assert element.is_displayed()
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//form[@id='loginForm']/h2")))
        assert element.is_displayed()

    # Backgroung image, url, email input, password input, login button, forgot password
    def test_backgroungimage_url_email_input_password_input_login_button_forgot_password(self):
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='password']")))
        assert element.is_displayed()
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='email']")))
        assert element.is_displayed()
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//button[@id='loginButton']")))
        assert element.is_displayed()
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//a[@id='forgetPwdBtn']")))
        assert element.is_displayed()

    # Designer clicks on login button with empty email and password
    def test_designer_clicks_on_login_button_with_empty_email_and_password(self):
        time.sleep(5)
        self.browser.find_element(By.XPATH, "//button[@id='loginButton']").click()

    # Designer should get er get error message Emailid is required and Password is required
    def test_designer_should_get_error_message_emailid_is_required_password_is_required(self):
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//label[normalize-space()='EmailId is required.']")))
        assert element.is_displayed()
        wait = WebDriverWait(self.browser, 1)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//label[normalize-space()='Password is required.']")))
        assert element.is_displayed()

    # Designer enters valid email id
    def test_designer_enters_valid_email_id(self):
        csv_data = self.test_read_csv()
        Email = csv_data[1][0]
        print(Email)
        self.browser.find_element(By.XPATH, "//input[@id='email']").send_keys(Email)
        time.sleep(10)

    #  # Designer clicks on forgot password?
    #  def test_designer_clicks_on_forgot_password(self):
    #      self.browser.find_element(By.XPATH, "//a[@id='forgetPwdBtn']").click()
    #
    # # Designer should get toast message Email with new password will be sent if you are a registered user
    #  def test_designer_should_get_toast_message_email_with_new_password_will_be_sent_if_you_are_a_registered_user(self):
    #      wait = WebDriverWait(self.browser, 1)
    #      element = wait.until(EC.presence_of_element_located(
    #          (By.XPATH, "(.//*[normalize-space(text()) and normalize-space(.)='Please Wait'])[1]/following::span[1]")))
    #      assert element.is_displayed()
    #      self.browser.find_element(By.XPATH, "//input[@id='email']").clear()

    # Designer clicks on login button with valid email id and password
    def test_designer_clicks_on_login_button_with_valid_email_id_and_password(self):
        self.browser.find_element(By.XPATH, "//input[@id='email']").clear()
        wait = WebDriverWait(self.browser, 5)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='email']")))
        assert element.is_displayed()
        csv_data = self.test_read_csv()
        email = self.csv_data[2][0]
        password = self.csv_data[2][1]
        self.browser.find_element(By.XPATH, "//input[@id='email']").send_keys(email)
        self.browser.find_element(By.XPATH, "//input[@id='password']").send_keys(password)
        self.browser.find_element(By.XPATH, "//button[@id='loginButton']").click()

    # Designer should navigate to cegame dashboard screen
    def test_designer_should_navigate_to_cegame_dashboard_screen(self):
        time.sleep(2)
        wait = WebDriverWait(self.browser, 10)
        element = wait.until(EC.presence_of_element_located((By.XPATH, "//a[@id='add-game-button']")))
        assert element.is_displayed()
        attach(data=self.browser.get_screenshot_as_png())



