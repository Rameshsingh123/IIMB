import re

text = "The quick brown fox\njumps 1 over the lazy dog.\n" \
       "The quick brown fox\njumps 2 over the lazy dog."

matches = re.findall(r"The.*?dog", text, re.DOTALL)

print(matches)

match = re.search(r"The.*?dog\.", text, re.DOTALL)

if match:
    print([match.group()])
